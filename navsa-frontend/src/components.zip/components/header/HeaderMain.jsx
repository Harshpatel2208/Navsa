import { Link } from "react-router-dom";
import {
  FaSearch,
  FaHeart,
  FaShoppingBasket,
  FaUser,
} from "react-icons/fa";

import logo from "../../assets/logo.png";
import awards from "../../assets/award.jpg";

export default function HeaderMain() {
  return (
    <div
      style={{
        width: "100%",
        background: "#ffffff",
        borderBottom: "1px solid #e9ecef",
      }}
    >
      <div
        style={{
          maxWidth: "1600px",
          margin: "0 auto",
          padding: "20px 40px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "30px",
          flexWrap: "wrap",
        }}
      >
        {/* Left */}

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "18px",
          }}
        >
          <img
            src={awards}
            alt="Award"
            style={{
              height: "58px",
              objectFit: "contain",
            }}
          />

          <Link to="/">
            <img
              src={logo}
              alt="Navsa"
              style={{
                height: "72px",
                objectFit: "contain",
              }}
            />
          </Link>

          <img
            src={awards}
            alt="Award"
            style={{
              height: "58px",
              objectFit: "contain",
            }}
          />
        </div>

        {/* Search */}

        <div
          style={{
            flex: 1,
            display: "flex",
            minWidth: "320px",
            maxWidth: "700px",
          }}
        >
          <input
            type="text"
            placeholder="Search by Product, Brand or Barcode..."
            style={{
              flex: 1,
              padding: "15px 18px",
              border: "2px solid #ececec",
              borderRight: "none",
              outline: "none",
              fontSize: "15px",
            }}
          />

          <button
            style={{
              width: "65px",
              border: "none",
              background: "#f58220",
              color: "#fff",
              cursor: "pointer",
              fontSize: "20px",
            }}
          >
            <FaSearch />
          </button>
        </div>

        {/* Right */}

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "18px",
          }}
        >
          {/* Account */}

          <Link
            to="/account"
            style={{
              textDecoration: "none",
            }}
          >
            <div
              style={{
                background: "#f58220",
                color: "#fff",
                padding: "12px 18px",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                borderRadius: "5px",
                fontWeight: 600,
              }}
            >
              <FaUser />

              Account
            </div>
          </Link>

          {/* Wishlist */}

          <Link
            to="/wishlist"
            style={{
              textDecoration: "none",
              color: "#082b53",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                fontWeight: 600,
              }}
            >
              <FaHeart color="#f58220" />

              Wishlist
            </div>
          </Link>

          {/* Basket */}

          <Link
            to="/basket"
            style={{
              textDecoration: "none",
            }}
          >
            <div
              style={{
                background: "#082b53",
                color: "#fff",
                padding: "12px 18px",
                borderRadius: "5px",
                display: "flex",
                alignItems: "center",
                gap: "10px",
                fontWeight: 600,
              }}
            >
              <FaShoppingBasket />

              <div>
                <div style={{ fontSize: "13px" }}>Basket</div>

                <div
                  style={{
                    fontSize: "11px",
                    opacity: 0.8,
                  }}
                >
                  £0.00
                </div>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}