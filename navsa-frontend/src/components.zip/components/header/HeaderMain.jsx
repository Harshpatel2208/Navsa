// // import { Link } from "react-router-dom";
// // import {
// //   FaSearch,
// //   FaHeart,
// //   FaShoppingBasket,
// //   FaUser,
// // } from "react-icons/fa";

// // import logo from "../../assets/logo.png";
// // import awards from "../../assets/award.jpg";

// // export default function HeaderMain() {
// //   return (
// //     <div
// //       style={{
// //         width: "100%",
// //         background: "#ffffff",
// //         borderBottom: "1px solid #e9ecef",
// //       }}
// //     >
// //       <div
// //         style={{
// //           maxWidth: "1600px",
// //           margin: "0 auto",
// //           padding: "20px 40px",
// //           display: "flex",
// //           alignItems: "center",
// //           justifyContent: "space-between",
// //           gap: "30px",
// //           flexWrap: "wrap",
// //         }}
// //       >
// //         {/* Left */}

// //         <div
// //           style={{
// //             display: "flex",
// //             alignItems: "center",
// //             gap: "18px",
// //           }}
// //         >
// //           <img
// //             src={awards}
// //             alt="Award"
// //             style={{
// //               height: "58px",
// //               objectFit: "contain",
// //             }}
// //           />

// //           <Link to="/">
// //             <img
// //               src={logo}
// //               alt="Navsa"
// //               style={{
// //                 height: "72px",
// //                 objectFit: "contain",
// //               }}
// //             />
// //           </Link>

// //           <img
// //             src={awards}
// //             alt="Award"
// //             style={{
// //               height: "58px",
// //               objectFit: "contain",
// //             }}
// //           />
// //         </div>

// //         {/* Search */}

// //         <div
// //           style={{
// //             flex: 1,
// //             display: "flex",
// //             minWidth: "320px",
// //             maxWidth: "700px",
// //           }}
// //         >
// //           <input
// //             type="text"
// //             placeholder="Search by Product, Brand or Barcode..."
// //             style={{
// //               flex: 1,
// //               padding: "15px 18px",
// //               border: "2px solid #ececec",
// //               borderRight: "none",
// //               outline: "none",
// //               fontSize: "15px",
// //             }}
// //           />

// //           <button
// //             style={{
// //               width: "65px",
// //               border: "none",
// //               background: "#f58220",
// //               color: "#fff",
// //               cursor: "pointer",
// //               fontSize: "20px",
// //             }}
// //           >
// //             <FaSearch />
// //           </button>
// //         </div>

// //         {/* Right */}

// //         <div
// //           style={{
// //             display: "flex",
// //             alignItems: "center",
// //             gap: "18px",
// //           }}
// //         >
// //           {/* Account */}

// //           <Link
// //             to="/account"
// //             style={{
// //               textDecoration: "none",
// //             }}
// //           >
// //             <div
// //               style={{
// //                 background: "#f58220",
// //                 color: "#fff",
// //                 padding: "12px 18px",
// //                 display: "flex",
// //                 alignItems: "center",
// //                 gap: "8px",
// //                 borderRadius: "5px",
// //                 fontWeight: 600,
// //               }}
// //             >
// //               <FaUser />

// //               Account
// //             </div>
// //           </Link>

// //           {/* Wishlist */}

// //           <Link
// //             to="/wishlist"
// //             style={{
// //               textDecoration: "none",
// //               color: "#082b53",
// //             }}
// //           >
// //             <div
// //               style={{
// //                 display: "flex",
// //                 alignItems: "center",
// //                 gap: "8px",
// //                 fontWeight: 600,
// //               }}
// //             >
// //               <FaHeart color="#f58220" />

// //               Wishlist
// //             </div>
// //           </Link>

// //           {/* Basket */}

// //           <Link
// //             to="/basket"
// //             style={{
// //               textDecoration: "none",
// //             }}
// //           >
// //             <div
// //               style={{
// //                 background: "#082b53",
// //                 color: "#fff",
// //                 padding: "12px 18px",
// //                 borderRadius: "5px",
// //                 display: "flex",
// //                 alignItems: "center",
// //                 gap: "10px",
// //                 fontWeight: 600,
// //               }}
// //             >
// //               <FaShoppingBasket />

// //               <div>
// //                 <div style={{ fontSize: "13px" }}>Basket</div>

// //                 <div
// //                   style={{
// //                     fontSize: "11px",
// //                     opacity: 0.8,
// //                   }}
// //                 >
// //                   £0.00
// //                 </div>
// //               </div>
// //             </div>
// //           </Link>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // }
// import { Link } from "react-router-dom";
// import {
//   FaSearch,
//   FaHeart,
//   FaShoppingBasket,
//   FaUser,
// } from "react-icons/fa";

// import logo from "../../assets/logo.png";
// import awards from "../../assets/award.jpg";
// import { useCart } from "../../context/CartContext";

// export default function HeaderMain() {
//   const { wishlistCount, basketCount, basketTotal } = useCart();

//   return (
//     <div
//       style={{
//         width: "100%",
//         background: "#ffffff",
//         borderBottom: "1px solid #e9ecef",
//       }}
//     >
//       <div
//         style={{
//           maxWidth: "1600px",
//           margin: "0 auto",
//           padding: "20px 40px",
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "space-between",
//           gap: "30px",
//           flexWrap: "wrap",
//         }}
//       >
//         {/* Left */}

//         <div
//           style={{
//             display: "flex",
//             alignItems: "center",
//             gap: "18px",
//           }}
//         >
//           <img
//             src={awards}
//             alt="Award"
//             style={{
//               height: "58px",
//               objectFit: "contain",
//             }}
//           />

//           <Link to="/">
//             <img
//               src={logo}
//               alt="Navsa"
//               style={{
//                 height: "72px",
//                 objectFit: "contain",
//               }}
//             />
//           </Link>

//           <img
//             src={awards}
//             alt="Award"
//             style={{
//               height: "58px",
//               objectFit: "contain",
//             }}
//           />
//         </div>

//         {/* Search */}

//         <div
//           style={{
//             flex: 1,
//             display: "flex",
//             minWidth: "320px",
//             maxWidth: "700px",
//           }}
//         >
//           <input
//             type="text"
//             placeholder="Search by Product, Brand or Barcode..."
//             style={{
//               flex: 1,
//               padding: "15px 18px",
//               border: "2px solid #ececec",
//               borderRight: "none",
//               outline: "none",
//               fontSize: "15px",
//             }}
//           />

//           <button
//             style={{
//               width: "65px",
//               border: "none",
//               background: "#f58220",
//               color: "#fff",
//               cursor: "pointer",
//               fontSize: "20px",
//             }}
//           >
//             <FaSearch />
//           </button>
//         </div>

//         {/* Right */}

//         <div
//           style={{
//             display: "flex",
//             alignItems: "center",
//             gap: "18px",
//           }}
//         >
//           {/* Account */}

//           <Link
//             to="/account"
//             style={{
//               textDecoration: "none",
//             }}
//           >
//             <div
//               style={{
//                 background: "#f58220",
//                 color: "#fff",
//                 padding: "12px 18px",
//                 display: "flex",
//                 alignItems: "center",
//                 gap: "8px",
//                 borderRadius: "5px",
//                 fontWeight: 600,
//               }}
//             >
//               <FaUser />

//               Account
//             </div>
//           </Link>

//           {/* Wishlist */}

//           <Link
//             to="/wishlist"
//             style={{
//               textDecoration: "none",
//               color: "#082b53",
//             }}
//           >
//             <div
//               style={{
//                 display: "flex",
//                 alignItems: "center",
//                 gap: "8px",
//                 fontWeight: 600,
//                 position: "relative",
//               }}
//             >
//               <span style={{ position: "relative" }}>
//                 <FaHeart color="#f58220" />
//                 {wishlistCount > 0 && (
//                   <span
//                     style={{
//                       position: "absolute",
//                       top: "-9px",
//                       right: "-11px",
//                       background: "#082b53",
//                       color: "#fff",
//                       fontSize: "10px",
//                       fontWeight: 700,
//                       borderRadius: "50%",
//                       minWidth: "16px",
//                       height: "16px",
//                       display: "flex",
//                       alignItems: "center",
//                       justifyContent: "center",
//                       padding: "0 3px",
//                     }}
//                   >
//                     {wishlistCount}
//                   </span>
//                 )}
//               </span>

//               Wishlist
//             </div>
//           </Link>

//           {/* Basket */}

//           <Link
//             to="/basket"
//             style={{
//               textDecoration: "none",
//             }}
//           >
//             <div
//               style={{
//                 background: "#082b53",
//                 color: "#fff",
//                 padding: "12px 18px",
//                 borderRadius: "5px",
//                 display: "flex",
//                 alignItems: "center",
//                 gap: "10px",
//                 fontWeight: 600,
//                 position: "relative",
//               }}
//             >
//               <span style={{ position: "relative" }}>
//                 <FaShoppingBasket />
//                 {basketCount > 0 && (
//                   <span
//                     style={{
//                       position: "absolute",
//                       top: "-9px",
//                       right: "-9px",
//                       background: "#f58220",
//                       color: "#fff",
//                       fontSize: "10px",
//                       fontWeight: 700,
//                       borderRadius: "50%",
//                       minWidth: "16px",
//                       height: "16px",
//                       display: "flex",
//                       alignItems: "center",
//                       justifyContent: "center",
//                       padding: "0 3px",
//                     }}
//                   >
//                     {basketCount}
//                   </span>
//                 )}
//               </span>

//               <div>
//                 <div style={{ fontSize: "13px" }}>Basket</div>

//                 <div
//                   style={{
//                     fontSize: "11px",
//                     opacity: 0.8,
//                   }}
//                 >
//                   £{basketTotal.toFixed(2)}
//                 </div>
//               </div>
//             </div>
//           </Link>
//         </div>
//       </div>
//     </div>
//   );
// }

// import { Link, useNavigate } from 'react-router-dom'
// import { useState } from 'react'
// import {
//   FaSearch,
//   FaHeart,
//   FaShoppingBasket,
//   FaUser,
// } from 'react-icons/fa'
// import { useCart } from '../../context/CartContext'
// import './HeaderMain.css'

// export default function HeaderMain() {
//   const navigate = useNavigate()
//   const { wishlistCount, basketCount, basketTotal } = useCart()
//   const [search, setSearch] = useState('')

//   function handleSubmit(event) {
//     event.preventDefault()

//     const value = search.trim()
//     navigate(value ? `/shop?search=${encodeURIComponent(value)}` : '/shop')
//   }

//   return (
//     <div className="header-main">
//       <div className="header-main__inner">
//         <div className="header-main__brand">
//           <img
//             src="/logos/award.jpg"
//             alt="King's Award"
//             className="header-main__award"
//           />

//           <Link to="/" className="header-main__logo-link">
//             <img
//               src="/logos/navsa-logo.png"
//               alt="NAVSA International"
//               className="header-main__logo"
//             />
//           </Link>

//           <img
//             src="/logos/award.jpg"
//             alt="King's Award"
//             className="header-main__award"
//           />
//         </div>

//         <form className="header-main__search" onSubmit={handleSubmit}>
//           <input
//             type="search"
//             value={search}
//             onChange={event => setSearch(event.target.value)}
//             placeholder="Search by Product, Brand or Barcode..."
//             aria-label="Search products"
//           />

//           <button type="submit" aria-label="Search">
//             <FaSearch />
//           </button>
//         </form>

//         <div className="header-main__actions">
//           <Link to="/account" className="header-action header-action--account">
//             <FaUser />
//             <span>Account</span>
//           </Link>

//           <Link to="/wishlist" className="header-action header-action--wishlist">
//             <span className="header-action__icon">
//               <FaHeart />
//               {wishlistCount > 0 && (
//                 <span className="header-count header-count--navy">
//                   {wishlistCount}
//                 </span>
//               )}
//             </span>
//             <span>Wishlist</span>
//           </Link>

//           <Link to="/basket" className="header-action header-action--basket">
//             <span className="header-action__icon">
//               <FaShoppingBasket />
//               {basketCount > 0 && (
//                 <span className="header-count header-count--orange">
//                   {basketCount}
//                 </span>
//               )}
//             </span>

//             <span className="header-basket-copy">
//               <strong>Basket</strong>
//               <small>£{Number(basketTotal || 0).toFixed(2)}</small>
//             </span>
//           </Link>
//         </div>
//       </div>
//     </div>
//   )
// }

import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import {
  FaSearch,
  FaHeart,
  FaShoppingBasket,
  FaUser,
} from 'react-icons/fa'
import { useCart } from '../../context/CartContext'
import './HeaderMain.css'

export default function HeaderMain() {
  const navigate = useNavigate()
  const { wishlistCount, basketCount, basketTotal } = useCart()
  const [search, setSearch] = useState('')

  function handleSubmit(event) {
    event.preventDefault()

    const value = search.trim()
    navigate(value ? `/shop?search=${encodeURIComponent(value)}` : '/shop')
  }

  return (
    <div className="header-main">
      <div className="header-main__brand-row">
        <div className="header-main__side header-main__side--left">
          <img
            src="/logos/award.jpg"
            alt="King's Award for Enterprise"
            className="header-main__award"
          />

          <Link
            to="/become-a-customer"
            className="header-main__customer-button"
          >
            Become a Customer
          </Link>
        </div>

        <Link to="/" className="header-main__logo-link">
          <img
            src="/logos/navsa-logo.png"
            alt="NAVSA International"
            className="header-main__logo"
          />
        </Link>

        <div className="header-main__side header-main__side--right">
          <Link to="/account" className="header-main__account-button">
            <FaUser />
            <span>Account</span>
          </Link>

          <img
            src="/logos/award.jpg"
            alt="King's Award for Enterprise"
            className="header-main__award"
          />
        </div>
      </div>

      <div className="header-main__utility-row">
        <form className="header-main__search" onSubmit={handleSubmit}>
          <input
            type="search"
            value={search}
            onChange={event => setSearch(event.target.value)}
            placeholder="Search Directory of 20,000+ British Products"
            aria-label="Search products"
          />

          <button type="submit" aria-label="Search">
            <FaSearch />
          </button>
        </form>

        <div className="header-main__actions">
          <Link to="/wishlist" className="header-main__wishlist">
            <span className="header-main__icon-wrap">
              <FaHeart />
              {wishlistCount > 0 && (
                <span className="header-main__count header-main__count--wishlist">
                  {wishlistCount}
                </span>
              )}
            </span>
            <span>Wishlist</span>
          </Link>

          <Link to="/basket" className="header-main__basket">
            <span className="header-main__icon-wrap">
              <FaShoppingBasket />
              {basketCount > 0 && (
                <span className="header-main__count header-main__count--basket">
                  {basketCount}
                </span>
              )}
            </span>

            <span className="header-main__basket-copy">
              <strong>{basketCount} items</strong>
              <small>£{Number(basketTotal || 0).toFixed(2)}</small>
            </span>
          </Link>
        </div>
      </div>
    </div>
  )
}

