import { useState, useEffect } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { colors, fonts } from '../theme'

function Shop() {
  const [searchParams] = useSearchParams()
  const categoryFilter = searchParams.get('category') || ''

  const [products, setProducts] = useState([])
  const [total, setTotal] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [lastPage, setLastPage] = useState(1)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  const loadProducts = async (page = 1) => {
    setLoading(true)
    try {
      let url = `https://britishfoodwarehouse.co.uk/api/products?page=${page}`
      if (categoryFilter) url += `&category=${encodeURIComponent(categoryFilter)}`
      if (search) url += `&search=${encodeURIComponent(search)}`
      const response = await fetch(url)
      const data = await response.json()
      setProducts(data.data)
      setTotal(data.total)
      setCurrentPage(data.current_page)
      setLastPage(data.last_page)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    setSearch('')
    loadProducts(1)
  }, [categoryFilter])

  const formatDate = (d) => {
    if (!d) return '—'
    const date = new Date(d)
    if (isNaN(date.getTime())) return d
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
  }

  return (
    <div style={{ width: '100%', background: colors.paper, fontFamily: fonts.body }}>

      {categoryFilter && (
        <div style={{ width: '100%', background: '#f58220', padding: '12px 6vw', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ color: '#fff', fontWeight: 700, fontSize: '14px' }}>
            CATEGORY: {categoryFilter.toUpperCase()}
          </span>
          <Link to="/shop" style={{ color: '#fff', fontSize: '13px', textDecoration: 'none', fontWeight: 600 }}>
            ✕ Clear Filter
          </Link>
        </div>
      )}

      <div style={{
        width: '100%', background: '#082b53', padding: '20px 6vw',
        display: 'flex', justifyContent: 'center', gap: '12px'
      }}>
        <input
          type="text"
          placeholder="Search by product, brand or code..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyUp={(e) => e.key === 'Enter' && loadProducts(1)}
          style={{ padding: '12px 16px', width: '420px', border: 'none', fontFamily: fonts.body }}
        />
        <button
          onClick={() => loadProducts(1)}
          style={{ background: '#f58220', color: '#fff', border: 'none', padding: '12px 26px', fontWeight: 600, cursor: 'pointer' }}
        >
          Search
        </button>
      </div>

      <div style={{ maxWidth: '1600px', margin: '0 auto', padding: '34px 6vw' }}>
        <p style={{ fontFamily: fonts.mono, fontSize: '13px', color: colors.inkMuted, marginBottom: '24px' }}>
          SHOWING {products.length} OF {total} PRODUCTS
          {categoryFilter && ` IN "${categoryFilter.toUpperCase()}"`}
        </p>

        {loading ? (
          <h2 style={{ textAlign: 'center', color: '#082b53' }}>Loading...</h2>
        ) : products.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px', color: colors.inkMuted }}>
            <div style={{ fontSize: '40px', marginBottom: '16px' }}>🔍</div>
            <h3 style={{ color: '#082b53' }}>No products found</h3>
            <p>Try a different category or search term.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '22px' }}>
            {products.map((product) => (
              <div key={product.id} style={{ background: '#fff', border: `1px solid ${colors.hairline}` }}>
                <div style={{
                  width: '100%', height: '190px', background: '#EFEDE6',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: '#A7AAB2', fontFamily: fonts.mono, fontSize: '12px'
                }}>
                  NO IMAGE
                </div>

                <div style={{ padding: '18px' }}>
                  <h3 style={{ fontFamily: fonts.display, fontSize: '15px', color: '#082b53', minHeight: '44px', margin: '0 0 10px' }}>
                    {product.description}
                  </h3>

                  <div style={{ display: 'flex', gap: '6px', marginBottom: '12px' }}>
                    <span style={{ background: colors.paper, color: '#082b53', fontFamily: fonts.mono, fontSize: '11px', padding: '3px 8px' }}>
                      {product.brand?.brand_name || 'BRAND'}
                    </span>
                    <span style={{ background: '#f0fdf4', color: '#166534', fontFamily: fonts.mono, fontSize: '11px', padding: '3px 8px' }}>
                      {product.category?.category_name || 'CATEGORY'}
                    </span>
                  </div>

                  <div style={{ fontSize: '24px', fontWeight: 700, color: '#1F7A4D', marginBottom: '14px' }}>
                    £{product.price}
                  </div>

                  <div style={{
                    fontFamily: fonts.mono, fontSize: '12px', color: colors.inkMuted,
                    display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', lineHeight: '1.6'
                  }}>
                    <div>CODE {product.reference}</div>
                    <div>EAN {product.barcode_ean}</div>
                    <div>CASE {product.barcode_case}</div>
                    <div>UNITS {product.inner_case_quantity}</div>
                    <div>WT {product.weight}kg</div>
                    <div>VOL {product.volume}m³</div>
                    <div>BBD {formatDate(product.bbd)}</div>
                    <div>{product.intra_country}</div>
                    <div>LAYER {product.layer_quantity}</div>
                    <div>PALLET {product.pallet_quantity}</div>
                  </div>

                  <Link
                    to={`/product/${product.id}`}
                    style={{ textDecoration: 'none', display: 'block', marginTop: '16px' }}
                  >
                    <button style={{
                      width: '100%', background: '#082b53', color: '#fff',
                      border: 'none', padding: '11px', fontWeight: 600, cursor: 'pointer'
                    }}>
                      View Details
                    </button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}

        <div style={{ marginTop: '40px', textAlign: 'center', fontFamily: fonts.mono, fontSize: '13px' }}>
          {currentPage > 1 && (
            <button onClick={() => loadProducts(currentPage - 1)} style={{ padding: '10px 16px', marginRight: '10px' }}>
              ← PREV
            </button>
          )}
          <span style={{ color: '#082b53', fontWeight: 600 }}>PAGE {currentPage} / {lastPage}</span>
          {currentPage < lastPage && (
            <button onClick={() => loadProducts(currentPage + 1)} style={{ padding: '10px 16px', marginLeft: '10px' }}>
              NEXT →
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

export default Shop