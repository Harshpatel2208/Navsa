import { Link } from 'react-router-dom'
import { colors, fonts } from '../theme'

function Wishlist() {
  return (
    <div style={{ width: '100%', minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: colors.paper, padding: '60px 6vw' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: '40px', marginBottom: '14px' }}>♥</div>
        <h2 style={{ fontFamily: fonts.display, color: colors.navy, marginBottom: '10px' }}>Your Wishlist is Empty</h2>
        <p style={{ color: colors.inkMuted, fontSize: '14px', marginBottom: '24px' }}>
          Browse the catalogue and save products you're interested in.
        </p>
        <Link to="/shop">
          <button style={{ background: colors.accent, color: '#fff', border: 'none', padding: '12px 28px', fontWeight: 600, cursor: 'pointer' }}>
            Browse Products
          </button>
        </Link>
      </div>
    </div>
  )
}

export default Wishlist