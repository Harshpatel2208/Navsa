import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Brands() {
  const [brands, setBrands] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/brands-list.json")
      .then((res) => res.json())
      .then((data) => setBrands(data));
  }, []);

  const filtered = brands.filter((b) =>
    b.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: "40px" }}>
      <h1 style={{ textAlign: "center" }}>OUR BRANDS</h1>

      <div style={{ textAlign: "center", margin: "20px" }}>
        <input
          type="text"
          placeholder="Search brands..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{
            padding: "10px",
            width: "300px",
            borderRadius: "6px"
          }}
        />
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
          gap: "20px"
        }}
      >
        {filtered.map((brand, i) => (
          <Link
            key={i}
            to={`/shop?brand=${brand.name}`}
            style={{
              textDecoration: "none",
              textAlign: "center",
              border: "1px solid #eee",
              padding: "15px",
              borderRadius: "10px",
              transition: "0.3s"
            }}
          >
            <img
              src={`/brands/${brand.file}`}
              alt={brand.name}
              style={{
                width: "100%",
                height: "80px",
                objectFit: "contain"
              }}
            />

            <p style={{ marginTop: "10px", color: "#082b53" }}>
              {brand.name}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default Brands;