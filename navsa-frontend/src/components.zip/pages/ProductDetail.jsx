import Barcode from 'react-barcode'
import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { colors, fonts } from '../theme'


export default function ProductDetail() {
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [caseQty, setCaseQty] = useState(0)
  const [layerQty, setLayerQty] = useState(0)
  const [palletQty, setPalletQty] = useState(0)
  const [barcodeTab, setBarcodeTab] = useState('ean')

  useEffect(() => {
    setLoading(true)
    fetch(`https://britishfoodwarehouse.co.uk/api/products/${id}`)
      .then(r => {
        if (!r.ok) throw new Error('Product not found')
        return r.json()
      })
      .then(d => { setProduct(d); setLoading(false) })
      .catch(e => { setError(e.message); setLoading(false) })
  }, [id])

  const formatDate = (d) => {
    if (!d) return '—'
    const date = new Date(d)
    if (isNaN(date.getTime())) return d
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })
  }

  const totalCases = caseQty + (layerQty * (product?.layer_quantity || 0)) + (palletQty * (product?.pallet_quantity || 0))

  if (loading) return (
    <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <p style={{ fontFamily: fonts.body, color: colors.inkMuted, fontSize: '16px' }}>Loading product...</p>
    </div>
  )

  if (error) return (
    <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '16px' }}>
      <p style={{ fontFamily: fonts.body, color: 'red', fontSize: '16px' }}>{error}</p>
      <Link to="/shop" style={{ color: '#082b53', fontWeight: 600 }}>← Back to Shop</Link>
    </div>
  )

  if (!product) return null

  return (
    <div style={{ width: '100%', background: colors.paper, fontFamily: fonts.body }}>

      {/* Breadcrumb */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.hairline}`, padding: '14px 6vw' }}>
        <div style={{ maxWidth: '1600px', margin: '0 auto', fontFamily: fonts.mono, fontSize: '12px', color: colors.inkMuted }}>
          <Link to="/" style={{ color: colors.inkMuted, textDecoration: 'none' }}>Home</Link>
          {' › '}
          <Link to="/shop" style={{ color: colors.inkMuted, textDecoration: 'none' }}>Shop</Link>
          {product.category && (
            <>
              {' › '}
              <Link
                to={`/shop?category=${encodeURIComponent(product.category.category_name)}`}
                style={{ color: colors.inkMuted, textDecoration: 'none' }}
              >
                {product.category.category_name}
              </Link>
            </>
          )}
          {' › '}
          <span style={{ color: '#082b53' }}>{product.description}</span>
        </div>
      </div>

      {/* Main content */}
      <div style={{ maxWidth: '1600px', margin: '0 auto', padding: '40px 6vw' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '50px', alignItems: 'start' }}>

          {/* Left — image */}
          <div>
            <div style={{
              background: '#fff', border: `1px solid ${colors.hairline}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              height: '420px', borderRadius: '4px'
            }}>
              <div style={{ textAlign: 'center', color: '#A7AAB2', fontFamily: fonts.mono, fontSize: '13px' }}>
                <div style={{ fontSize: '48px', marginBottom: '12px' }}>📦</div>
                NO IMAGE
                <div style={{ marginTop: '8px', fontSize: '11px' }}>{product.web_image}</div>
              </div>
            </div>


        {/* Barcode Section */}
        {/* Barcode section */}
<div
  style={{
    background: '#fff',
    border: `1px solid ${colors.hairline}`,
    marginTop: '20px',
    borderRadius: '4px',
    overflow: 'hidden',
  }}
>
  {/* Header */}
  <div
    style={{
      padding: '18px 20px 10px',
      fontFamily: fonts.mono,
      fontSize: '12px',
      color: colors.inkMuted,
      fontWeight: 600,
      letterSpacing: '1px',
    }}
  >
    BARCODES
  </div>

  {/* Tabs */}
  <div
    style={{
      display: 'flex',
      borderBottom: `1px solid ${colors.hairline}`,
      padding: '0 20px',
      gap: '10px',
    }}
  >
    <button
      onClick={() => setBarcodeTab('ean')}
      style={{
        background:
          barcodeTab === 'ean'
            ? '#082b53'
            : '#f5f6f8',
        color:
          barcodeTab === 'ean'
            ? '#fff'
            : '#666',
        border: 'none',
        padding: '9px 18px',
        fontSize: '12px',
        fontWeight: 700,
        fontFamily: fonts.mono,
        cursor: 'pointer',
        borderRadius: '4px 4px 0 0',
        transition: '0.2s',
      }}
    >
      EAN
    </button>

    {product.barcode_case && (
      <button
        onClick={() => setBarcodeTab('case')}
        style={{
          background:
            barcodeTab === 'case'
              ? '#082b53'
              : '#f5f6f8',
          color:
            barcodeTab === 'case'
              ? '#fff'
              : '#666',
          border: 'none',
          padding: '9px 18px',
          fontSize: '12px',
          fontWeight: 700,
          fontFamily: fonts.mono,
          cursor: 'pointer',
          borderRadius: '4px 4px 0 0',
          transition: '0.2s',
        }}
      >
        CASE ITF-14
      </button>
    )}
  </div>

  {/* Barcode */}
  <div
    style={{
      padding: '35px 20px',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      background: '#fff',
      minHeight: '180px',
    }}
  >
    {barcodeTab === 'ean' && product.barcode_ean && (
      <Barcode
        value={product.barcode_ean}
        format="EAN13"
        width={2}
        height={90}
        fontSize={16}
        margin={10}
        displayValue={true}
      />
    )}

    {barcodeTab === 'case' && product.barcode_case && (
      <Barcode
        value={product.barcode_case}
        format="ITF14"
        width={2}
        height={90}
        fontSize={16}
        margin={10}
        displayValue={true}
      />
    )}
  </div>
</div>
</div>

          {/* Right — product info */}
          <div>
            {/* Brand + Category badges */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '14px', flexWrap: 'wrap' }}>
              {product.brand && (
                <span style={{ background: '#eef2ff', color: '#3730a3', fontFamily: fonts.mono, fontSize: '12px', padding: '4px 10px', fontWeight: 600 }}>
                  {product.brand.brand_name}
                </span>
              )}
              {product.category && (
                <span style={{ background: '#f0fdf4', color: '#166534', fontFamily: fonts.mono, fontSize: '12px', padding: '4px 10px', fontWeight: 600 }}>
                  {product.category.category_name}
                </span>
              )}
            </div>

            {/* Title */}
            <h1 style={{ fontFamily: fonts.display, color: '#082b53', fontSize: 'clamp(20px, 2.5vw, 28px)', margin: '0 0 10px', lineHeight: '1.3' }}>
              {product.description}
            </h1>

            {/* Price */}
            <div style={{ fontSize: '32px', fontWeight: 700, color: '#1F7A4D', margin: '16px 0' }}>
              £{product.price}
            </div>

            {/* Key specs table */}
            <div style={{ background: '#fff', border: `1px solid ${colors.hairline}`, marginBottom: '24px' }}>
              {[
                ['Navsa Product Code', product.reference],
                ['Brand', product.brand?.brand_name],
                ['Description', product.description],
                ['Units per Case', product.inner_case_quantity],
                ['Unit Weight', product.weight ? `${product.weight} kg` : null],
                ['Unit Volume', product.volume ? `${product.volume} m³` : null],
                ['Best Before Date (indicative)', formatDate(product.bbd)],
                ['Country of Origin', product.intra_country],
                ['Comm Code', product.comm_code],
                ['VAT Code', product.vat_code],
                ['Shelf Life (days)', product.shelf_life],
              ].map(([label, value]) => value ? (
                <div key={label} style={{
                  display: 'grid', gridTemplateColumns: '180px 1fr',
                  borderBottom: `1px solid ${colors.hairline}`,
                  padding: '10px 16px', fontSize: '14px'
                }}>
                  <span style={{ color: colors.inkMuted, fontWeight: 500 }}>{label}</span>
                  <span style={{ color: '#082b53', fontWeight: 600 }}>{value}</span>
                </div>
              ) : null)}
            </div>

            {/* Quantity Options */}
            <div style={{ background: '#fff', border: `1px solid ${colors.hairline}`, padding: '20px', marginBottom: '20px' }}>
              <div style={{ fontFamily: fonts.mono, fontSize: '12px', color: colors.inkMuted, marginBottom: '16px', fontWeight: 600 }}>
                QUANTITY OPTIONS
              </div>

              {[
                { label: 'Case', perLabel: `${product.inner_case_quantity} Units per Case`, qty: caseQty, setQty: setCaseQty },
                { label: 'Layer', perLabel: `${product.layer_quantity} Cases per Layer`, qty: layerQty, setQty: setLayerQty },
                { label: 'Pallet', perLabel: `${product.pallet_quantity} Cases per Pallet`, qty: palletQty, setQty: setPalletQty },
              ].map(({ label, perLabel, qty, setQty }) => (
                <div key={label} style={{
                  display: 'grid', gridTemplateColumns: '80px 1fr auto',
                  alignItems: 'center', gap: '12px', marginBottom: '12px',
                  padding: '10px 0', borderBottom: `1px solid ${colors.hairline}`
                }}>
                  <span style={{ fontWeight: 600, color: '#082b53', fontSize: '14px' }}>{label}</span>
                  <span style={{ color: colors.inkMuted, fontSize: '13px' }}>{perLabel}</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <button
                      onClick={() => setQty(q => Math.max(0, q - 1))}
                      style={{ width: '32px', height: '32px', border: `1px solid ${colors.hairline}`, background: '#fff', cursor: 'pointer', fontWeight: 700, fontSize: '16px' }}
                    >−</button>
                    <span style={{ width: '32px', textAlign: 'center', fontWeight: 600, fontFamily: fonts.mono }}>{qty}</span>
                    <button
                      onClick={() => setQty(q => q + 1)}
                      style={{ width: '32px', height: '32px', border: `1px solid ${colors.hairline}`, background: '#fff', cursor: 'pointer', fontWeight: 700, fontSize: '16px' }}
                    >+</button>
                  </div>
                </div>
              ))}

              <div style={{ marginTop: '14px', fontFamily: fonts.mono, fontSize: '13px', color: '#082b53', fontWeight: 600 }}>
                {totalCases} total cases selected
              </div>
            </div>

            {/* Add to Basket */}
            <button style={{
              width: '100%', padding: '16px', background: '#f58220', color: '#fff',
              border: 'none', fontWeight: 700, fontSize: '16px', cursor: 'pointer', marginBottom: '12px'
            }}>
              Add to Basket
            </button>

            <button style={{
              width: '100%', padding: '14px', background: 'transparent', color: '#082b53',
              border: '2px solid #082b53', fontWeight: 600, fontSize: '14px', cursor: 'pointer'
            }}>
              ♥ Add to Wishlist
            </button>
          </div>
        </div>

        {/* Bottom — extra details */}
        <div style={{ marginTop: '50px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px' }}>

          {/* Logistics */}
          <div style={{ background: '#fff', border: `1px solid ${colors.hairline}`, padding: '24px' }}>
            <h3 style={{ fontFamily: fonts.display, color: '#082b53', fontSize: '16px', marginBottom: '16px' }}>
              Case & Pallet Information
            </h3>
            {[
              ['Cases per Layer', product.layer_quantity],
              ['Cases per Pallet', product.pallet_quantity],
              ['Outer Case Qty', product.outer_case_quantity],
              ['Case Volume (m³)', product.volume],
            ].map(([label, value]) => value ? (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: `1px solid ${colors.hairline}`, fontSize: '14px' }}>
                <span style={{ color: colors.inkMuted }}>{label}</span>
                <span style={{ fontWeight: 600, color: '#082b53' }}>{value}</span>
              </div>
            ) : null)}
          </div>

          {/* Trade/Customs */}
          <div style={{ background: '#fff', border: `1px solid ${colors.hairline}`, padding: '24px' }}>
            <h3 style={{ fontFamily: fonts.display, color: '#082b53', fontSize: '16px', marginBottom: '16px' }}>
              Trade & Customs
            </h3>
            {[
              ['Commodity Code', product.comm_code],
              ['Country of Origin', product.intra_country],
              ['Intra Type', product.intra_type],
              ['Supplier Reference', product.supplier_reference],
            ].map(([label, value]) => value ? (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: `1px solid ${colors.hairline}`, fontSize: '14px' }}>
                <span style={{ color: colors.inkMuted }}>{label}</span>
                <span style={{ fontWeight: 600, color: '#082b53' }}>{value}</span>
              </div>
            ) : null)}
          </div>

          {/* Web description */}
          {product.web_long_description && (
            <div style={{ background: '#fff', border: `1px solid ${colors.hairline}`, padding: '24px' }}>
              <h3 style={{ fontFamily: fonts.display, color: '#082b53', fontSize: '16px', marginBottom: '12px' }}>
                Product Description
              </h3>
              <p style={{ color: colors.inkMuted, fontSize: '14px', lineHeight: '1.7' }}>
                {product.web_long_description}
              </p>
            </div>
          )}
        </div>

        {/* Back link */}
        <div style={{ marginTop: '40px' }}>
          <Link
            to={product.category ? `/shop?category=${encodeURIComponent(product.category.category_name)}` : '/shop'}
            style={{ color: '#082b53', fontFamily: fonts.mono, fontSize: '13px', textDecoration: 'none', fontWeight: 600 }}
          >
            ← Back to {product.category?.category_name || 'Shop'}
          </Link>
        </div>
      </div>
    </div>
  )
}